"""Core components for the security configuration auditing tool."""

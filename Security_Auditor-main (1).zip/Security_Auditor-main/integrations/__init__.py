"""Integration modules for external APIs and services."""

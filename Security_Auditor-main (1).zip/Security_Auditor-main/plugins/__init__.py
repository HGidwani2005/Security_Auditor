"""Plugin system for security checks and remediations."""

"""Windows-specific security checks and remediations."""
